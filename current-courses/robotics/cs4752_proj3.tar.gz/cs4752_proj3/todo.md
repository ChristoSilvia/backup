* move to center of goal with velocity control
