# Final Project

### Project 3 of Cornell CS 4752
###### By Isaac Qureshi, Chris Silvia, Zach Vinegar
Final Project (100 points)
Proposal Milestone: 3:35pm, Fri, Dec 4, 2015
Competition 5pm, Monday, Dec 14, 2015
Report due: 5pm, Thursday, Dec 17, 2015
Location: Gates G03/G05 (food will be provided)



Extras:


---
The package contains the following modules of note:

####  (`.py`)

* 
* `$ roslaunch cs4752_proj3 .launch`
