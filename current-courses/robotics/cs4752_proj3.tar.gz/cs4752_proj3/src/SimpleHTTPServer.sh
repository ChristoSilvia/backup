#!/bin/sh
cd ~/ros_ws/src/cs4752_proj3/opentype/
python -m SimpleHTTPServer